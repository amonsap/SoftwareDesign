package SingletonFactory;

public interface Factory {
	 Bar create(int id);
}
