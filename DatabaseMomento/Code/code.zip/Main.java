public class Main {

	public static void main(String[] args) {
		InventoryDecorator ks = new InventoryDecorator("KS-Shop");
		CareTaker redo = new CareTaker();
	
		Book b1 = new Book("Math",500,2);
		Book b2 = new Book("Thai",400,2);
		Book b3 = new Book("Eng",300,2);
		Book b4 = new Book("Social",500,2);
		Book b5 = new Book("Med",600,2);
		Book b6 = new Book("Me",700,2);
		
		ks.addBook(b1);
		ks.addBook(b2);
		ks.addBook(b3);
		ks.addBook(b4);
		
		ks.copyBook("Math", 2);
		ks.copyBook("Thai", 3);
		ks.sellBook("Thai",2);
		
		System.out.println("Show stock before save");
		ks.showAllOfStock();
		System.out.println();
		ks.addBook(b5);
		ks.copyBook("Thai", 3); 
		ks.save();
		System.out.println("Show Save");
		ks.showAllSave(); // show save
				
		ks.copyBook("Thai", 3);
		ks.addBook(b6);
		ks.changePrice("Thai", 800);
		ks.restore();
		System.out.println("Show Stock After restored");
		ks.showAllSave();
		
		ks.findPriceByID(1);
		ks.findPriceByName("Math");
		ks.findQuantityByID(6);
		ks.findQuantityByName("France");
		

	}
}
