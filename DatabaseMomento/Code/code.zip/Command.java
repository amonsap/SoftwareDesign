
abstract class Command {
	public abstract void execute(Inventory newInvent);

}
