
public class ChangePriceCommand extends Command{

	private String bookName;
	private Integer newPrice;
	
	public ChangePriceCommand(String newBookName, Integer newPrice){
		this.bookName = newBookName; 
		this.newPrice = newPrice;
	}
	@Override
	public void execute(Inventory newInvent) {
		newInvent.changePrice(this.bookName,this.newPrice);
	}

}
