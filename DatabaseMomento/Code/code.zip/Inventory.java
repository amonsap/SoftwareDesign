import java.util.ArrayList;

public class Inventory implements InventoryInterface {
	
	private String inventoryName;
	private ArrayList<Book> books = new ArrayList<>();
	private Memento memento = new Memento();
	private InventoryDecorator invent ;
	
	public Inventory() {
		
	}
	public ArrayList<Book> getBooks() {
		return this.books;
	}
	public void setBook(ArrayList<Book> books) {
		this.books = books;
	}
	public void setNameInventory(String name) {
		this.inventoryName = name;
	}

	@Override
	public void addBook(Book newBook) {
		this.books.add(newBook);
	}

	@Override
	public void sellBook(String bookName,int number) {
		for(Book book : this.books){
			if(book.getName().equals(bookName)){
				if( book.getQuantity() > 0 &&book.getQuantity() > number) {
					book.changeQuantity((-1)*number);
				}
				else {
					System.out.println(book.getName() +" not enough.");
				}
			}
		}	
	}

	@Override
	public void copyBook(String bookName, int NumberOfCopy) {
		for(Book book : this.books){
			if(book.getName().equals(bookName)){
				book.changeQuantity(NumberOfCopy);	
			}
		}	
	}

	@Override
	public void changePrice(String bookName, int price) {
		for(Book book : this.books){
			if(book.getName().equals(bookName)){
				book.setPrice(price);	
			}
		}	
		
	}

	@Override
	public void findPriceByName(String bookName) {
		boolean notFound = true;
		for(Book book : this.books){
			if(book.getName().equals(bookName)){
				System.out.println(book.getName()+" have price "+  book.getPrice());
				notFound = false;
			}
		}
		if(notFound) {
			System.out.println("Not found this book.");
		}
	}

	@Override
	public void findPriceByID(Integer bookID) {
		boolean notFound = true;
		for(Book book : this.books){
			if(book.getUniqueID().equals(bookID)){
				System.out.println(book.getName()+" have price "+  book.getPrice());
				notFound = false;
			}
		}
		if(notFound) {
			System.out.println("Not found this book.");
		}
	}

	@Override
	public void findQuantityByName(String nameBook) {
		boolean notFound = true;
		for(Book book : this.books){
			if(book.getName().equals(nameBook)){
				System.out.println(book.getName()+" have quanlity "+  book.getQuantity());
				notFound = false;
			}
		}
		if(notFound) {
			System.out.println("Not found this book.");
		}
		
	}
	
	@Override
	public void findQuantityByID(Integer bookID) {
		boolean notFound = true;
		for(Book book : this.books){
			if(book.getUniqueID().equals(bookID)){
				System.out.println(book.getName()+" have quanlity "+ book.getQuantity());
				notFound = false;
			}
		}
		if(notFound) {
			System.out.println("Not found this book.");
		}
	}

	@Override
	public void showAllOfStock() {
		System.out.println(">>> "+this.inventoryName+" Inventory <<<");
		System.out.println("====================================================================");
		System.out.println("Book Name \t|Book price \t|Book qaunlity");
		System.out.println("====================================================================");
		for(Book book : this.books) {
			System.out.format("%-20s%-20d%d\n",book.getName(),book.getPrice(),book.getQuantity());
		}
		System.out.println("====================================================================");
	}
	@Override
	public void save() {
		 //memento.saveState(getBooks());
	}
	@Override
	public void restore() {
		//invent.save();
		//invent.getInvent().getBooks();	
		
	}
	@Override
	public void undo() {
		// TODO Auto-generated method stub
		
	}
}
