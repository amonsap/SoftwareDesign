import java.util.ArrayList;

public class Memento {
	
	private ArrayList<Book> books;
	public void saveState(ArrayList<Book> newBooks){
		this.books = new ArrayList<Book>(newBooks);	
		
	}
	public ArrayList<Book> getState(){
		
		return this.books;
	}

}
