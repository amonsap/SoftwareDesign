
public class AddBookCommand extends Command {

	private Book book;
	public AddBookCommand(Book newBook) {
		this.book = newBook; 
	}
	@Override
	public void execute(Inventory newInvent) {
		newInvent.addBook(book);
		
	}

}
