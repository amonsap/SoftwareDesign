
public class SellBookCommand extends Command{
	

	private String bookName;
	private String fileName = "Command.ser";
	private int numberOfSell;
	
	public SellBookCommand (String newBookName,int numberOfSell){
		this.bookName = newBookName; 
		this.numberOfSell = numberOfSell;
		}
	@Override
	public void execute(Inventory newInvent) {
		newInvent.sellBook(this.bookName,this.numberOfSell);
	}

}
