
public class AddCopyCommand extends Command{

	private String bookName;
	private Integer numberOfCopy;
	
	
	public AddCopyCommand(String newBookName, Integer newNumberOfCopy){
		this.bookName = newBookName; 
		this.numberOfCopy = newNumberOfCopy;
	}
	@Override
	public void execute(Inventory newInvent) {
		newInvent.copyBook(this.bookName,this.numberOfCopy);
	}

}


