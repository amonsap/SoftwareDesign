
import java.util.ArrayList;

public class InventoryDecorator implements InventoryInterface {
	
	
	private Inventory invent = new Inventory();
	private InventoryStored inv = new InventoryStored() ;
	private ArrayList<Command> commandCollection = new ArrayList<Command>();
	private CareTaker careTaker = new CareTaker();
	private Memento memento = new Memento();
	private ArrayList<Memento> prev = new ArrayList<Memento>();
	
	public InventoryDecorator(String nameInventory) {
		invent.setNameInventory(nameInventory);
	}

	public Inventory getInvent() {
		return invent;
	}

	public void setInvent(Inventory invent) {
		
		this.invent = invent;
	}
	
	@Override
	public void addBook(Book newBook) {
		AddBookCommand addBook= new AddBookCommand(newBook);
	    addBook.execute(this.invent);
	}

	@Override
	public void sellBook(String bookName, int numberOfSell) {
		
	}

	@Override
	public void copyBook(String bookName, int numberOfCopy) {
		AddCopyCommand addCopy = new AddCopyCommand(bookName, numberOfCopy);
		addCopy.execute(invent);
	}

	@Override
	public void changePrice(String bookName, int newPrice) {
		ChangePriceCommand changePrice = new ChangePriceCommand(bookName, newPrice);
		changePrice.execute(invent);

	}

	@Override
	public void findPriceByName(String bookName) {
		invent.findPriceByName(bookName);

	}

	@Override
	public void findPriceByID(Integer bookID) {
		invent.findPriceByID(bookID);
	}

	@Override
	public void findQuantityByName(String bookName) {
		invent.findQuantityByName(bookName);

	}

	@Override
	public void findQuantityByID(Integer bookID) {
		invent.findQuantityByID(bookID);
	}

	@Override
	public void showAllOfStock() {
		invent.showAllOfStock();

	}
	
	public void showAllSave() {
		inv.showAllOfStock();
	}
	private void replyCommands(Inventory invent){
		
			for(Command command : commandCollection){
		         command.execute(invent);
			}
	}

	@Override
	public void save() {
		this.memento.saveState(this.invent.getBooks());
		careTaker.addMemento(this.memento);
		this.inv.addBook(this.invent.getBooks());
	}

	@Override
	public void restore() {
		memento = careTaker.getMemento();
		//this.invent.setBook(memento.getState());
		this.invent.setBook(memento.getState());
		//this.replyCommands(invent);
		
	}

	@Override
	public void undo() {
		//System.out.println(inv.getHistory());
		
	}

}
