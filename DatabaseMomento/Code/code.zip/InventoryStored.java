
import java.util.ArrayList;

public class InventoryStored  {
	
	private ArrayList<BookStored> book = new ArrayList<>();
	
	public void addBook(ArrayList<Book> book) {		
		for(Book b : book) {
			this.book.add(new BookStored(b.getName(),b.getPrice(),b.getQuantity()) );
		}
	}
	
	public ArrayList<BookStored> getHistory(){
		return this.book;
	}
	public void showAllOfStock() {
		System.out.println("====================================================================");
		System.out.println("Book Name \t|Book price \t|Book qaunlity");
		System.out.println("====================================================================");
		for(BookStored book : this.book) {
			System.out.format("%-20s%-20d%d\n",book.getName(),book.getPrice(),book.getQuantity());
		}
		System.out.println("====================================================================");
	}
	
}
