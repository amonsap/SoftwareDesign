import java.util.ArrayList;

public class CareTaker {
	
	private ArrayList<Memento> mementoList = new ArrayList<>();
	private Memento prev =  new Memento();
	
	public void addMemento(Memento memento) {
		this.mementoList.add(memento);
		this.prev = memento;
		
		
	}	
	public Memento getMemento() {
		//System.out.println(prev);
		return this.prev;
		
	}
}
