
public interface InventoryInterface {
	
	public void addBook(Book newBook);
	public void sellBook(String bookName,int number);
	public void copyBook(String bookName, int number);
	public void changePrice(String bookName,int price);
	public void findPriceByName(String nameBook);
	public void findPriceByID(Integer bookID);
	public void findQuantityByName(String nameBook);
	public void findQuantityByID(Integer bookID);
	public void showAllOfStock();
	public void save();
	public void restore();
	public void undo();
}
