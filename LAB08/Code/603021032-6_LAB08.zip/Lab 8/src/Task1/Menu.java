package Task1;

import java.util.Iterator;

public interface Menu {
	public Iterator createIterator();
}
