package Task2;

public interface State {
	public boolean pressPlay();
	public boolean pressPause();
	public boolean pressStop();
}
