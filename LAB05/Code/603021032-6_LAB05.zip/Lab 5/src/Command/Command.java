package Command;

public interface Command {
	public void undo();
	public void redo();
}