package Template;

public class Omelette {
	public void crackingEggs(int numOfEggs1) {
		System.out.println("Cracking: " + numOfEggs1 +  "eggs");
	}
	
	public void prepareEggs() {
		System.out.println("Stirring the eggs.");
	}
	
	public void cook() {
		System.out.println("Flipping the omelette while cooking.");
	}
	
	public void serve() {
		System.out.println("Putting the eggs on the plate.\n");
	}

}