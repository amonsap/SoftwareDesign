package Task2;

public class SwedishBuyer extends Buyer {
	public SwedishBuyer(Mediator mediator) {
		super(mediator, "KRONA");
		this.mediator.registerSwedishBuyer(this);
	}
}
