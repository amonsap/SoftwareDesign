package Task1;

public class Circle extends Shape {
	private int x,y,r;
	
	public Circle(int x, int y, int r, DrawingService drawingService) {
		super(drawingService);
		this.x = x;
		this.y = y;
		this.r = r;
	}

	@Override
	public void draw() {
		drawingService.drawCircle(x, y, r);
	}

}
