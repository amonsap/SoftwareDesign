package Task1; 

public interface Quackable {
	public void quack();
}
